package com.edu.serviceImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.edu.common.DAO;
import com.edu.service.BulletinService;
import com.edu.vo.BulletinVO;
import com.edu.vo.ReplyVO;

public class BulletinDAO extends DAO implements BulletinService{

	
	// 전체 리스트 
	@Override
	public List<BulletinVO> selectList() {
		connect();
		String sql = "SELECT * FROM bbs ORDER BY 1";
		
		List<BulletinVO> list = new ArrayList<>();
		try {
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			while(rs.next()) {
				BulletinVO bulletin = new BulletinVO();
				bulletin.setBbsId(rs.getInt("bbs_id"));
				bulletin.setBbsTitle(rs.getString("bbs_title"));
				bulletin.setBbsWriter(rs.getString("bbs_writer"));
				bulletin.setBbsContent(rs.getString("bbs_content"));
				bulletin.setBbsImage(rs.getString("bbs_image"));
				bulletin.setBbsHit(rs.getInt("bbs_hit"));
				bulletin.setBbsCreateDate(rs.getString("bbs_create_date"));
				list.add(bulletin);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return list;
	}

	// 단건 선택
	@Override
	public BulletinVO selectOne(int bbsId) {
		connect();
		String sql = "SELECT * FROM bbs WHERE bbs_id=?";
		BulletinVO bulletin = null;
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, bbsId);
			
			rs = psmt.executeQuery();
			if (rs.next()) {
				bulletin = new BulletinVO();
				
				bulletin.setBbsId(rs.getInt("bbs_id"));
				bulletin.setBbsTitle(rs.getString("bbs_title"));
				bulletin.setBbsWriter(rs.getString("bbs_writer"));
				bulletin.setBbsContent(rs.getString("bbs_content"));
				bulletin.setBbsImage(rs.getString("bbs_image"));
				bulletin.setBbsHit(rs.getInt("bbs_hit"));
				bulletin.setBbsCreateDate(rs.getString("bbs_create_date"));
				
				// 카운트증가
				updateCount(bbsId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return bulletin;
	}
	
	// 조회수 증가 
	public void updateCount(int id) {
		connect();
		String sql = "UPDATE bbs SET bbs_hit = bbs_hit+1 WHERE bbs_id=?";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, id);
			int r = psmt.executeUpdate();
			System.out.println(r + " 건 수정되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
	}
	

	// 입력
	@Override
	public BulletinVO insert(BulletinVO vo) {
		connect();
		
		String sql1 = "SELECT bbs_id_seq.nextval FROM DUAL";
		String sql2 = "INSERT INTO bbs(bbs_id, bbs_title, bbs_content, bbs_writer, bbs_image, bbs_create_date, bbs_hit)"
						+ "VALUES(?,?,?,?,?,sysdate,0)";
		
		try {
			psmt = conn.prepareStatement(sql1);
			rs = psmt.executeQuery();
			int seq = 0;
			
			if(rs.next()) {
				seq = rs.getInt(1);	
			}
			psmt = conn.prepareStatement(sql2);
			psmt.setInt(1, seq);
			psmt.setString(2, vo.getBbsTitle());
			psmt.setString(3, vo.getBbsContent());
			psmt.setString(4, vo.getBbsWriter());
			psmt.setString(5, vo.getBbsImage());
			int r = psmt.executeUpdate();
			System.out.println(r + " 건이 입력되었습니다.");
			
			//입력값에 bbs_id값만 추가해서 반환
			vo.setBbsId(seq);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return vo;
	}

	// 수정
	@Override
	public BulletinVO update(BulletinVO vo) {
		connect();									//nvl 은 오라클 함수 -> null값을 처리합니다. 
		String sql = "UPDATE bbs SET bbs_title=?, bbs_content=?, bbs_image=nvl(?, bbs_image) WHERE bbs_id=?";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, vo.getBbsTitle());
			psmt.setString(2, vo.getBbsContent());
			psmt.setString(3, vo.getBbsImage());
			psmt.setInt(4, vo.getBbsId());
			int r = psmt.executeUpdate();
			System.out.println(r + " 건 변경(update)되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return vo;
		
	}

	// 삭제
	@Override
	public int delete(int bbsId) {
		connect();
		String sql = "DELETE FROM bbs WHERE bbs_id=?";
		
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, bbsId);
			int r = psmt.executeUpdate();
			System.out.println(r + " 건 삭제(delete)되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return bbsId;
	}

	
	// reply 댓글 
	@Override
	public List<ReplyVO> selectReplyList(int bbsId) {
		connect();
		String sql = "SELECT * FROM reply WHERE bbs_id=?";
		List<ReplyVO> rList = new ArrayList<>();
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, bbsId);
			rs = psmt.executeQuery();
			while(rs.next()) {
				ReplyVO vo = new ReplyVO();
				vo.setBbsId(rs.getInt("bbs_id"));
				vo.setReplyContent(rs.getString("reply_content"));
				vo.setReplyDate(rs.getString("reply_date"));
				vo.setReplyId(rs.getInt("reply_id"));
				vo.setReplyWriter(rs.getString("reply_writer"));
				
				rList.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return rList; //컬렉션에 값을 담아서 변환 
	}

	
	// reply 댓글 입력*수정
	@Override
	public ReplyVO insertReply(ReplyVO vo) {
		connect();
		String sql1 = "SELECT reply_id_seq.nextval, sysdate FROM DUAL";
		String sql2 = "INSERT INTO reply (reply_id, reply_content, reply_writer, reply_date, bbs_id)"
				+ "VALUES(?, ?, ?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'), ?)";
				// 4번쨰 index 데이트 값을 따로 위와 같이 처리. 
		try {
			psmt = conn.prepareStatement(sql1);
			rs = psmt.executeQuery();
			int replySeq = 0;
			String replyDate = "";
			
			if(rs.next()) {
				replySeq = rs.getInt(1);
				replyDate = rs.getString(2); // 2022-01-20 11:01:49
				System.out.println(replyDate);
			}
			psmt = conn.prepareStatement(sql2);
			psmt.setInt(1, replySeq);
			psmt.setString(2, vo.getReplyContent());
			psmt.setString(3, vo.getReplyWriter());
			psmt.setString(4, replyDate);
			psmt.setInt(5, vo.getBbsId());
			
			int r = psmt.executeUpdate();
			System.out.println(r + " 건 입력(reply-insert)되었습니다.");
			
			vo.setReplyId(replySeq); // 생성된 값
			vo.setReplyDate(replyDate); // 생성된 값
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return vo;
	}

		// reply 댓글 삭제
	@Override
	public boolean deleteReply(int rid) {
		connect();
		String sql = "DELETE FROM reply WHERE reply_id=?";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, rid);
			int r = psmt.executeUpdate();
			System.out.println(r + " 건 삭제(reply-delete)되었습니다.");
			
			if (r > 0) {//정상 삭제
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return false;
	}
}
