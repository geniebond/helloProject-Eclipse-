package com.edu.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.edu.common.Controller;
import com.edu.common.HttpUtil;
import com.edu.service.MemberService;
import com.edu.serviceImpl.MemberDAO;
import com.edu.vo.MemberVO;

public class LoginController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String path = "member/home.tiles";
		String id = req.getParameter("usderId"); //member-> loginForm 에 지정한 name값
		String pw = req.getParameter("userPw"); //member-> loginForm 에 지정한 name-userpw값

		MemberService service = new MemberDAO();
		MemberVO member = service.login(id, pw);

		// 로그인성공 -> home 페이지, login페이지에 -> 실패
		if (member == null) {
			path = "loginForm.do";
		} else {
			//로그인 성공하면 session에 id, name, mail값을 속성에 저장?
			HttpSession session = req.getSession(); /// 생성된 세션이 있다면 세션을 반환 없다면 -> 새롭게 세션 생성하여 반환함
			session.setAttribute("sessionId", member.getId());
			session.setAttribute("sessionName", member.getName());
			session.setAttribute("sessionMail", member.getMail());
			
		}
		HttpUtil.forward(req, resp, path);
	}

}
